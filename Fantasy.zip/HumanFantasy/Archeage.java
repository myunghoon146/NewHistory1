package HumanFantasy;
public class Archeage
{
    public static void main(String[] args) 
    {
        String archeage;
        long game;
        System.out.println("Create Archeage Game Program and Install Archeage World of Universe.");
    }
}