package Baroque;

public class VersaillesKingdom 
{
    public static void main(String[] args) 
    {
        String versailles;
        int kingdom;
        System.out.println("Establish Versailles Empire and Create Baroque Age Universe");    
    }    
}
