package Ancient;

public class AlanRepublic 
{
    public static void main(String[] args) 
    {
        String alan;
        short republic;

        protected AlanRepublic(String alan, short republic)
        {
            this.alan=alan;
            this.republic=republic;
            System.out.println("Republic: " +alan);
        }

        default void RepublicProcessor()
        {
            for(short republic:i)
            {
                System.out.println("Create Alan Republic World");
            }
        }

        protected static void UniverseProcessor()
        {
            System.out.println("Create Ancient World and Language and Universe!!!");
        }

        Stack<"Republic">("Alan Republic")=new Stack<>();

        System.out.println("Establish Ancient World of Universe and Alan Republic");

    }   
}
