package Kemorina;

public class ElizabethEmpire 
{
    public static void main(String[] args) 
    {
        String elizabeth;
        int empire;
        System.out.println("Establish Elizabeth Empire and Install Kemorina Universe and Planets.");    
    }    
}
