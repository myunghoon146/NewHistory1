package Rococo;

public class PrussiaEmpire 
{
    public static void main(String[] args) 
    {
        String prussia;
        long empire;
        System.out.println("Establish Prussia Empire and Install Rococo Age Universe and Planets.");    
    }   
}
