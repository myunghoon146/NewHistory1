package Renaissance;

public class FionaKingdom 
{
    public static void main(String[] args) 
    {
    String fiona;
    long kingdom;
    System.out.println("Establish Fiona Kingdom and Install Renaissance Universe."); 
    }   
}
