package Medieval;

public class StrathclydeEmpire 
{
    public static void main(String[] args) 
    {
        String strathclyde;
        int empire;
        
        protected StrathclydeEmpire(String strathclyde, int empire)
        {
            this.strathclyde=strathclyde;
            this.empire=empire;
            System.out.println("Empire: " +strathclyde);
        }

        protected void MedievalEmpireProcessor()
        {
            for(int i=235;i<90000007565;i++)
            {
                System.out.println("Create Strathclyde Empire in Medieval World of Universe");
            }
        }

        private static void MedievalUniverse()
        {
            System.out.println("Create and Initiate Medieval Universe from Earth to everywhere");
        }

        Stack<"MedievalEmpire">("Strathclyde Empire")=new Stack<>();

        System.out.println("Establish Strathclyde Empire and Medieval Universe.");
    }
}
