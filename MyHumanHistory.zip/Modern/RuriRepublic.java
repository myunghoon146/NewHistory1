package Modern;

public class RuriRepublic 
{
    public static void main(String[] args) 
    {
        String ruri;
        byte republic;
        System.out.println("Establish Ruri Republic and Install and Initiate Modern Universe.");    
    }    
}
